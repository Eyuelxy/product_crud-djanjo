from django.shortcuts import render
from .models import Products
from .forms import ProductForm


# Create your views here.
def index(request):
    product = Products.objects.all()
    return render(request, 'index.html', {'products': product})

def contact(request):
    return render(request, 'contact.html')

def addProduct(request):
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return index(request)
    else:
        form = ProductForm()
        return render(request, 'add_update.html', {'form': form})

def updateProduct(request,id):
    product = Products.objects.get(id=id)
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES, instance=product)
        if form.is_valid():
            form.save()
            return manageProducts(request)
    else:
        form = ProductForm(instance=product)
        return render(request, 'add_update.html', {'form': form})

def dleteProduct(request, id):
    product = Products.objects.get(id=id)
    if request.method == 'POST':
        product.delete()
        return manageProducts(request)
    return render(request, 'dlete.html', {'product': product})
    
def productDetail(request, id):
    product = Products.objects.get(id=id)
    return render(request, 'product detail.html', {'product': product})


def manageProducts(request):
    products = Products.objects.all()
    return render(request, 'manageproduct.html', {'products': products})


def testimonial(request):
    return render(request, 'testimonial.html')
