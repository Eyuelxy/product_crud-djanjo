from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static 

urlpatterns = [
    path("", views.index, name="index"),
    path('contact', views.contact, name='contact'),
    path('addProduct', views.addProduct, name='addProduct'),
    path('updateProduct<int:id>', views.updateProduct, name='updateProduct'),
    path('dleteProduct<int:id>', views.dleteProduct, name='deleteProduct'),
    path('manageProducts', views.manageProducts, name='manageProducts'),
    path('productDetail<int:id>', views.productDetail, name='productDetail'),
    path('testimonial', views.testimonial, name='testimonial'),
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)